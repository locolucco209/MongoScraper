#!/bin/bash

rm 'xlwings/tests/~$test book.xlsx'

$PYTHON setup.py install
