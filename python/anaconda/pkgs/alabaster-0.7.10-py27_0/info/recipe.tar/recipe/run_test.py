import alabaster

print(alabaster.get_path())
