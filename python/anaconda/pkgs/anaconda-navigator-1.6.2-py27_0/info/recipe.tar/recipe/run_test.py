import anaconda_navigator

print('anaconda_navigator.__version__: %s' % anaconda_navigator.__version__)
assert anaconda_navigator.__version__ == '1.6.2'
